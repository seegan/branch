window.ParsleyConfig = window.ParsleyConfig || {};
window.ParsleyConfig.i18n = window.ParsleyConfig.i18n || {};

window.ParsleyConfig.i18n.he = jQuery.extend(window.ParsleyConfig.i18n.he || {}, {
  dateiso: "ערך זה צריך להיות תאריך בפורמט (YYYY-MM-DD)."
});
