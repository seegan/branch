<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['branch_id'] = 3;