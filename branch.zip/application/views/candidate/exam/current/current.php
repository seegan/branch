            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->                      
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">

                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="filter-section">
                                            <div class="page-title-box action-header">
                                                <div>
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-10">

                                                       </div>
                                                        <div class="col-md-12 col-lg-2">
                                                            
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="clearfix"></div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="">
                                    <?php $this->load->view('candidate/exam/current/ajax/filter/list') ?>
                                </div>
                            </div>

                        </div>
                        <!-- end row -->

                    </div>
                    <!-- end container -->
                </div>
                <!-- end content -->

            </div>
            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->